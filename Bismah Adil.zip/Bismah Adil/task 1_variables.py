name = "Bismah"
age = 18
height = 5.5
is_student = True
print(name)
print("Age:", age)
print("Height:", height)
print("Student:", is_student)