a=10
b=3
add=a+b
print("Addition", a + b)
print("Subtraction", a - b)
print("Multiplication", a * b)
print("Division", a / b)
print("Floor division", a // b)
print("mModulus", a % b)
print("Exponent", a ** b)